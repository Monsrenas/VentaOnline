<div id="timer" class="modal modal-dialog" tabindex="10" role="dialog" style="border: none; width: 120px; max-width: 120px;  border:0;" aria-hidden="true">
  <div class="modal-dialog " style="background: none;  border:0;">
    <div class="modal-content" style="background: none;  border:0;">
       <img  src="{{'timer.gif'}}" alt="Timer" style="width: 120px;  border:0;"/>
    </div>
  </div>
</div>

 

<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>