<form action="{{url('Traslado')}}" method="post">
	@csrf

	<button type="submit">Trasladar</button>
</form>